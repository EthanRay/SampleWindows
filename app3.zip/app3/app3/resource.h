#define IDD_DIALOG_ABOUT                101
#define IDR_MENU_MAIN                   101
#define IDR_MENU_POPUP                  102
#define IDI_ICON_MAIN                   103
#define IDC_EDIT_ABOUT                  1001
#define ID_FILE_COPY                    40001
#define ID_FILE_SAVE40002               40002
#define ID_FILE_EXIT                    40003
#define ID_EIDT_COPY                    40004
#define ID_EIDT_PASTE                   40005
#define ID_HELP_ABOUT                   40006
#define ID_COPY_PASTE                   40007
#define ID_COPY_PASTE40008              40008
#define ID_POPUP_COPY                   40009
#define ID_POPUP_PASTE                  40010
#define ID_POPUP_CUT                    40011
#define ID_POPUP_INFO                   40012
#define ID_INFO_A                       40013
#define ID_INFO_B                       40014

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40015
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
